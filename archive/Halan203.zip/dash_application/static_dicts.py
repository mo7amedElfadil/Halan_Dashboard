from dash_application.input_data import input_data
sme_main = input_data()




sme_name_list = []

for sme_name in sme_main['sme_name'].unique():
    if sme_name_list == []:
        sme_name_list.append("")
    sme_name_list.append(sme_name)

sme_name_list.sort()
sme_name_list


Drivers_names_list = []

for driver_name in sme_main['driver_name'].unique():
    if Drivers_names_list == []:
        Drivers_names_list.append("")
    Drivers_names_list.append(driver_name)

Drivers_names_list.sort()
Drivers_names_list



order_reason_of_failure_list = []

for order_reason_of_failure in sme_main['order_reason_of_failure'].unique():
    if Drivers_names_list == []:
        order_reason_of_failure_list.append("")
    order_reason_of_failure_list.append(order_reason_of_failure)

#order_reason_of_failure_list.sort()




 #  features = {
 #   'Daily orders received': 'Daily orders received',
 #    'Weekly orders received' : 'Weekly orders received',
 #    'Monthly orders received' :'Monthly orders received',
 #    'Daily orders delivered':'Daily orders delivered',
 #    'Weekly orders delivered':'Weekly orders delivered',
 #     'Monthly orders delivered':'Monthly orders delivered',
 #    'Daily status comparison':'Daily status comparison',
 #    'Weekly status comparison':'Weekly status comparison',
 #     'Monthly status comparison':'Monthly status comparison',
 #    'SME status comparison Daily' :'SME status comparison Daily',
 #    'SME status comparison Weekly' :'SME status comparison Weekly',
 #    'SME status comparison Monthly' :'SME status comparison Monthly',
 #   'SME status percentage comparison Daily'    :'SME status percentage comparison Daily',
 #   'SME status percentage comparison Weekly'    :'SME status percentage comparison Weekly',
 #   'SME status percentage comparison Monthly'    :'SME status percentage comparison Monthly',
 #   'Daily status percentage comparison':'Daily status percentage comparison',
 #    'Daily status comparison':'Daily status comparison',
 #    'Order reason of failure':'Order reason of failure',
 #    'Halan GMV':'Halan GMV',
 #       }

features_graph_type = {
    'order_status_count':'order_status_count',
    "order_status_percentage":"order_status_percentage",
    'order_reason_of_failure':'order_reason_of_failure', #pie
     'GMV':'GMV',
}

features_order_status = {'Received':'Received',
                         "Delivered":"Delivered",
                         'Cancelled': 'Cancelled',
                         'Hold':'Hold',
                        }
#   {'label':i, 'value': i } for i in sme_main.columns,
features_order_period = {'Daily':'order_date', #ts
                         'Weekly': 'week',      #bar
                         'Monthly':'month_name',  #bar
                        }
features_stakeholder = {'Halan':'Halan',
                        'SME':'sme_name',
                        "Driver":"driver_name",
                       }

sme_columns = ['order_id', 'client_city', 'sme_name','order_value','order_date','driver_name','order_status','order_reason_of_failure','month_name','week','driver_fee',	'halan_return', 'sme_return']

dates_list_of_dict = []

for month in sme_main['month_name'].unique():
    dates_list_of_dict.append({'label':str(month),'value': month})

sme_status_options = []

for status in sme_main['order_status'].unique():
    sme_status_options.append({'label':str(status),'value': str(status)})

css_styles =  {
    'background':'#111111',
     'text':'#7FDBFF',
  'blue':'#5e72e4',
  'indigo': '#5603ad',
  'purple': '#8965e0',
  'pink': '#f3a4b5',
  'red': '#f5365c',
  'orange': '#fb6340',
  'yellow': '#ffd600',
  'green': '#2dce89',
  'teal': '#11cdef',
  'cyan': '#2bffc6',
  'white': '#ffffff',
  'gray': '#6c757d',
  'gray1':'#202020',
  'gray2':'#323232',
  'gray-dark': '#32325d',
  'light': '#ced4da',
  'lighter': '#e9ecef',
  'primary': '#e14eca',
  'secondary': '#f4f5f7',
  'success': '#00f2c3',
  'info': '#1d8cf8',
  'warning': '#ff8d72',
  'danger': '#fd5d93',
  'light': '#adb5bd',
  'dark': '#212529',
  'default': '#344675',
  'white': '#ffffff',
  
  'darker': 'black',
  'breakpoint-xs': 0,
  'breakpoint-sm': '576px',
  'breakpoint-md': '768px',
  'breakpoint-lg': '992px',
  'breakpoint-xl': '1200px',
  'font-family-sans-serif':' -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"',
  'font-family-monospace':' SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace', 
  }

#    c0 = { 'margin': '0',
#  'color': '#575962',
#  'font-size':'20px',
#  'font-weight':'400',
#  'line-height': '1.6',}


card_style_1 = { 
 'background' : '#ffd73e33' , 
 'color':css_styles['dark'],
 ' box-shadow': '0px 1px 15px 1px rgba(69, 65, 78, 0.08)',
 'border': '2px solid',
  'text-align': 'center',
  
  'position': 'relative',
  'border-radius': '5px',
  'background-color': '#212529',
  
  'resize': 'block',
  'display': 'flex',
 'border-top':'1px dotted #ebecec',
  'padding': '15px 25px !important',
  
 
}




  

font1 ={'color': css_styles['text'],                
                'family' : css_styles['font-family-monospace'],
                
                }


 
tab_style = {
   
    
    'fontWeight': 'bold',
    'border-radius': '5px',
    'background-color': '#F2F2F2',
    'box-shadow': '4px 4px 4px 4px lightgrey',
       
  
    
    'background-repeat':'repeat',
    
}
 



NAVBAR_STYLE = {
  
    "background-color": "#f8f9fa",
    'background-image': 'linear-gradient(135deg, #f8f9fa 0%, #c4e0e5 50%)',
    'box-shadow': '4px 4px  lightgrey',
      'fontWeight': 'bold',
    'border-radius': '5px',
    
}

art_style ={
     
     'margin': '2px',
     'padding':'2px',
 
     'border-radius': '60px',
    'background-color': '#e9ecef',
     'box-shadow': '2px 6px 15px 0 rgba(69,65,78,.1)',
     'border': '2px dotted #212529',
   
     }

CONTENT_STYLE = {
    
   
    "padding": "20px",
    
    "position": "relative",
   
 
}
graph_style = {

    "margin":'4px',
    
  
}


theme = {
    
'dark': False,
   
    'color': 'black',
     "position": "relative",
      'box-shadow': '4px 4px 4px 4px lightgrey',
     
  
    
      
}

h1_style ={'textAlign':'center',
        'color':css_styles['darker'] ,
        "background-color":'#f4f5f7',
        'background-image': 'linear-gradient(135deg, #4ca1af 0%, #c4e0e5 100%)',
            
        'font-family': css_styles['font-family-monospace'],
        'font-weight': '400',
        
        
        }

        
comp_style ={
        'color':css_styles['darker'] ,
    'background-image': 'linear-gradient(135deg, #ffffff 0%,#6c757d 100%)',
      'white-space':'nowrap',
     'border-radius': '60px',
      'text-align': 'center',
        }

group_style = {
    "position": "relative",
        'display': 'flex',
    'justify-content':'space-between',
    'align-items': 'flex-end',
    'vertical-align': 'baseline',
    "padding": "0 3em 0 3em",
  
  
    
}