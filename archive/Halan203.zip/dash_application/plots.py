
import pandas as pd
import plotly.express as px
import plotly.graph_objs as go
from dash_application.static_dicts import css_styles, font1, features_order_period,features_stakeholder,features_order_status,features_graph_type    
from plotly.subplots import make_subplots
from skimage import io 



class report_plots:
    def plots_img():
        img = io.imread('dash_application/assets/img.jpg')
        fig = px.imshow(img, height=400)
        fig.update_layout(hovermode=False, title="There is no graph representation for the selected options")
        fig.update_xaxes(showticklabels=False)
        fig.update_yaxes(showticklabels=False)
        return fig
           

    def plots_pie_traces(sme_graph,stakeholder,order_period):
        plot = 'px'
        if plot =='px':
            if stakeholder!='Halan':

                r = int(len(sme_graph[features_stakeholder[stakeholder]].unique())/2) 
                n = len(sme_graph[features_stakeholder[stakeholder]].unique())           
                fig = make_subplots(rows=r, cols=2,  specs=[[{'type':'pie'}, {'type':'pie'}] for i in range(r)])
        
                stakeholder_list = sme_graph[features_stakeholder[stakeholder]].unique()
                
        
                it = 0
                for i in range(r):
                    for j in range(2):
                        if n==0:
                            break
                        else:
                            
                            df3 = sme_graph[sme_graph[features_stakeholder[stakeholder]]==(stakeholder_list[it])]
                            fig.add_trace( go.Pie(labels=df3['order_reason_of_failure'],values=df3['order_count'], title=stakeholder_list[it]), #difference in % is due to gaps in langs due to top 10
                                    i+1, j+1)
                            it= it+1



                fig.update_traces(textposition='inside')
                fig.update_layout(uniformtext_minsize=12, uniformtext_mode='hide',height=300*r+140, margin=dict(t=120,l=20,b=20,r=20),
                title="{} Order Reason of failure for {}".format(order_period,stakeholder), legend=dict(
                        orientation="h", y=1, yanchor="bottom", x=1, xanchor="right"
                    ))
                

                return fig

            else:
                r = 1
                          
                fig = make_subplots(rows=r, cols=r,  specs=[[{'type':'pie'}] for i in range(r)])
        
               
                
                
                df3 = sme_graph
                fig.add_trace( go.Pie(labels=df3['order_reason_of_failure'],values=df3['order_count'], title="Halan"), #difference in % is due to gaps in langs due to top 10
                        1, 1)
               


                fig.update_traces(textposition='inside',texttemplate='%{percent}')
                fig.update_layout(uniformtext_minsize=12, uniformtext_mode='hide',margin=dict(t=120,l=20,b=20,r=20),height=300*r+140,
                title="Order Reason of failure for {}".format(stakeholder), legend=dict(
                         orientation="v", 
                    ))
                

                return fig


    def plots_percentage(sme_graph,order_period):

        plot = 'px'
        if plot =='px':
            fig = px.line(sme_graph, x=features_order_period[order_period], y='status_percentage',text = 'status_percentage',
             title='{} orders status percentage'.format(order_period),template = 'plotly_white')#tenplates = plotly_white plotly_dark ggplot2 simple_white seaborn
            fig.update_layout(showlegend=True,   margin=dict(t=120,l=10,b=10,r=10),height=200+140,
             title="{} Order Status percentage ".format(order_period), )
            fig.update_traces(texttemplate='%{text:.2%}',)

            return fig
            

          #  return # groupnorm (str (default None)) – One of 'fraction' or 'percent'. If 'fraction', the value of each point is divided by the sum of all values at that location coordinate. 'percent' is the same but multiplied by 100 to show percentages. None will stack up all values at each location coordinate.
        else:
            return {'data':[
                
                go.Scatter( 
                    x=sme_graph[features_order_period[order_period]],
                    y=sme_graph['status_percentage'],
                    
                     text=sme_graph['status_percentage'],
                     textfont_size=14,
                textposition='top right',
                     mode='lines+markers+text',
                     texttemplate='%{text:.2%}',
                marker = {'size':15, 'opacity':0.5,
                                'line':{'width':0.5} },
             
                     
                  )],

            'layout':go.Layout(
                title =  '{} orders percentage'.format(order_period),
                xaxis = dict(title = order_period),
                yaxis = dict(title = 'Status Percentage',tickformat= ',.2%',
                                range= [0,1]),
                autosize = True,
                showlegend=True,
                
                margin=dict(l=40, r=0, t=40, b=30),
                 hovermode= 'closest',
               plot_bgcolor = css_styles['gray1']  ,
                paper_bgcolor =css_styles['gray2'],
                
                font= font1,
           ) }
       
  
        
    def plots_bar(sme_graph,stakeholder,order_period,graph_type):
        if stakeholder != 'Halan':
            n_stake = len(sme_graph[features_stakeholder[stakeholder]].unique())
        n =  len(sme_graph[features_order_period[order_period]].unique())
        plot = 'px'
        if plot =='px':
            if stakeholder == "Halan":
                fig = px.bar(sme_graph, x='order_count', y=features_order_period[order_period],
                  title=" {} Order Status Count for {} ".format(order_period,stakeholder),
                color='order_count', color_continuous_scale = "darkmint",
                 orientation='h',text="order_count",template = 'plotly_white')#template = plotly_white plotly_dark ggplot2 simple_white seaborn
                fig.update_layout(showlegend=True,   margin=dict(t=120,l=50,b=40,r=50),height=200*(n)+160, 
                                 
                                
                                    legend=dict( title=None,
                        orientation="v", y=1, yanchor="bottom", x=1, xanchor="right"
                    )
                                )
                fig.update_traces(texttemplate='%{text:.3s}', textposition='auto')
                
                return fig
            elif n_stake>10:
                fig = px.bar(sme_graph, x='order_count', y=features_order_period[order_period], color=features_stakeholder[stakeholder],
                  title=" {} Order Status Count for {} ".format(order_period,stakeholder), 
                orientation='h',text="order_count",template = 'plotly_white')#template = plotly_white plotly_dark ggplot2 simple_white seaborn
                fig.update_layout(showlegend=True,   margin=dict(t=120,l=50,b=120,r=50),height=200*(n)+200, 
                                 
                                
                                    legend=dict( title=None,
                      orientation="h", y=-2, yanchor="bottom", x=1, xanchor="right"
                    )
                                )
                fig.update_traces(texttemplate='%{text:.3s}', textposition='auto')


                return fig
            else:
                fig = px.bar(sme_graph, x='order_count', y=features_order_period[order_period], color=features_stakeholder[stakeholder],
                title=" {} Order Status Count for {} ".format(order_period,stakeholder),
                orientation='h',text="order_count",template = 'plotly_white')#template = plotly_white plotly_dark ggplot2 simple_white seaborn
                fig.update_layout(showlegend=True,   margin=dict(t=120,l=50,b=120,r=50),height=200*(n)+140, 
                                    legend=dict( title=None,
                        orientation="h", y=1, yanchor="bottom", x=1, xanchor="right"
                    )
                                )
                fig.update_traces(texttemplate='%{text:.3s}', textposition='auto')


                return fig
        else:
            features_list = [features for features in sme_graph.columns]
            fig = px.bar(sme_graph, x=features_graph_type[graph_type], y='order_count',color=features_graph_type[graph_type],
             text=sme_graph['order_count'],title=" {} Order Status Count for {} ".format(order_period,stakeholder), template='plotly_white') #tenplates = plotly_white plotly_dark ggplot2 simple_white seaborn
            #fig.update_traces(texttemplate='%{text:.2s}', textposition='outside')
            fig.update_layout(showlegend=True,   margin=dict(t=120,l=50,b=120,r=50),height=200*(n)+40, 
                                    legend=dict( title=None,
                        orientation="h", y=1, yanchor="bottom", x=1, xanchor="right"
                    )
                                )
            fig.update_traces(textposition='auto',textfont_size=14)
    
        #   fig.show()
            return fig
      #  traces = []
    
        
        

     #      traces.append(
     #          go.Bar(
     #          y=sme_graph[features].values.tolist(), 
     #          x=sme_graph.index,
     #            
     #          textfont_size=14,
     #              textposition='auto',
     #            texttemplate='%{text:.3s}',
     #          text = sme_graph[features],     
     #         
     #         
     #          
     #    
     #          name = features,
     #      ))

     #  return {'data':
     #                  traces,
     #                  

     #              'layout':go.Layout(
     #                  title =  'GMV',
     #                  barmode='group',
     #                  xaxis = dict(title = order_period),
     #                  yaxis = dict(title = 'Order Count'),
     #            plot_bgcolor = css_styles['gray1']  ,
     #              paper_bgcolor =css_styles['gray2'],
     #                  autosize = True,
     #               font= font1,
     #              
     #               #margin=dict(l=40, r=0, t=40, b=30),
   # #           ) }

     
    def plots_gmv(sme_graph,order_period):

        plot = 'px'
        if plot =='px':
            if features_order_period[order_period]=='order_date':
                sme_graph = sme_graph.reset_index()
                
        
                fig = px.bar(sme_graph, y=['sme_return','driver_fee','halan_return'], x=features_order_period[order_period], 
                title='{} Gross Market Value '.format(order_period),#color=features_order_period[order_period],
                    #text=['driver_fee','halan_return','sme_return'],
                    
                    
                    text_auto=True,
                    orientation='v',template = 'plotly_white')#template = plotly_white plotly_dark ggplot2 simple_white seaborn
                fig.update_traces(textposition='auto')
                fig.update_layout(showlegend=True,   margin=dict(t=120,l=50,b=120,r=50),height=700, 
                                
                                font = dict(family="Rockwell",size=16),
                                    legend=dict(  title=None,
                         orientation="hzz", y=1, yanchor="bottom", x=1, xanchor="right"
                    )
                                )
                
                    
                return fig
            
            else:
                sme_graph = sme_graph.reset_index()
                n = len(sme_graph[features_order_period[order_period]].unique())
        
                fig = px.bar(sme_graph, x=['sme_return','driver_fee','halan_return'], y=features_order_period[order_period], title='{} there are {} '.format(order_period,n),#color=features_order_period[order_period],
                    #text=['driver_fee','halan_return','sme_return'],
                    text_auto=True,
                    orientation='h',template = 'plotly_white')#template = plotly_white plotly_dark ggplot2 simple_white seaborn
                fig.update_layout(showlegend=True,   margin=dict(t=120,l=50,b=120,r=50),height=200*(n)+140, 
                                 title='{} Gross Market Value '.format(order_period),
                                font = dict(family="Rockwell",size=16),
                                    legend=dict(
                        title=None, orientation="h", y=1, yanchor="bottom", x=1, xanchor="right"
                    )
                                )
            # fig.update_traces(texttemplate='%{text:.3s}', textposition='auto')
                    
                return fig
                
        else:
            traces = []
        
            for features in sme_graph.columns:
            

                traces.append(
                    go.Bar(
                    y=sme_graph[features].values.tolist(), 
                    x=sme_graph.index,
                    
                    textfont_size=14,
                        textposition='auto',
                    texttemplate='%{text:.3s}',
                    text = sme_graph[features],     
                
                
                    
            
                    name = features,
                ))

            return {'data':
                            traces,
                            

                        'layout':go.Layout(
                            title =  'GMV',
                            barmode='group',
                            xaxis = dict(title = order_period),
                            yaxis = dict(title = 'Order Count'),
                    plot_bgcolor = css_styles['gray1']  ,
                        paper_bgcolor =css_styles['gray2'],
                            autosize = True,
                        font= font1,
                        
                        #margin=dict(l=40, r=0, t=40, b=30),
                    ) }
    def plots_treemap(sme_graph,stakeholder,order_period):
    
        stakeholder_list = (sme_graph.groupby(features_stakeholder[stakeholder])['order_count'].sum().reset_index().nlargest(5,'order_count'))[features_stakeholder[stakeholder]].unique()
        sme_graph=sme_graph[sme_graph[features_stakeholder[stakeholder]].isin(stakeholder_list)]
        fig =px.treemap(sme_graph, path=[features_order_period[order_period], features_stakeholder[stakeholder],'order_reason_of_failure'], values='order_count', maxdepth=4,
                title='{} Order Reason of Failure for {} '.format(order_period,stakeholder),
                  color='order_reason_of_failure',template='plotly_dark') #tenplates = plotly_white plotly_dark ggplot2 simple_white seaborn presentation 
        
        fig.update_layout( height=800,margin=dict(t=70,l=0,b=20,r=0),
                 
            )
        return fig

    def plots_treemap_main(sme_graph,stakeholder):
        sme_graph['order_count'] = 1
        
        #stakeholder_list = (sme_graph.groupby(features_stakeholder[stakeholder])['order_count'].sum().reset_index().nlargest(5,'order_count'))[features_stakeholder[stakeholder]].unique()
        #sme_graph=sme_graph[sme_graph[features_stakeholder[stakeholder]].isin(stakeholder_list)]
        if stakeholder=='Halan':
            fig =px.treemap(sme_graph, path=['year','month_name','week','day','order_status','order_id'],
            title='{} Summary Tree Map '.format(stakeholder),
                  color='order_value',template='plotly_white', branchvalues ='total',
                  hover_data =['order_value','order_delivery_fees','halan_return','order_status','sme_name','driver_name'] ,
                  ) #tenplates = plotly_white plotly_dark ggplot2 simple_white seaborn presentation 
        
            fig.update_layout( height=700,margin=dict(t=70,l=0,b=20,r=0),
                    
                )
        else:
            fig =px.treemap(sme_graph, path=[ features_stakeholder[stakeholder],'year','month_name','week','day','order_status','order_id'],
            title='{} Summary Tree Map '.format(stakeholder), 
                  color= features_stakeholder[stakeholder],template='plotly_white', branchvalues ='total', maxdepth=4,
                   hover_data =['order_value','order_delivery_fees','halan_return','order_status','sme_name','driver_name'] ,
                   ) #tenplates = plotly_white plotly_dark ggplot2 simple_white seaborn presentation 
        
            fig.update_layout( height=700,margin=dict(t=70,l=0,b=20,r=0),
                    
                )
        return fig
        #make one for 
    def plots_sunburst(sme_graph,stakeholder,order_period):
        if stakeholder == "Halan":
            fig = px.sunburst(sme_graph, path=[features_order_period[order_period],'order_reason_of_failure'], values='order_count', 
            title='{} Order Reason of Failure for {} '.format(order_period,stakeholder),
            color=features_order_period[order_period],template='plotly_white') #tenplates = plotly_white plotly_dark ggplot2 simple_white seaborn presentation 
            fig.update_layout( height=700,margin=dict(t=120,l=0,b=20,r=0),
                 
            )
            return fig

        else:
            fig = px.sunburst(sme_graph, path=[features_order_period[order_period],'order_reason_of_failure', features_stakeholder[stakeholder]], values='order_count', 
            title='{} Order Reason of Failure for {} '.format(order_period,stakeholder),
            color=features_order_period[order_period],template='plotly_white') #tenplates = plotly_white plotly_dark ggplot2 simple_white seaborn presentation 
            fig.update_layout( height=700,margin=dict(t=120,l=0,b=20,r=0),
                 
            )
            return fig
    def plots_sunburst_percentage(sme_graph,stakeholder,order_period,order_status):
        if stakeholder == "Halan":
            fig = px.sunburst(sme_graph, path=[features_order_period[order_period],'order_status'],
             values='status_percentage', title="{} {} Status Percentage out of {} total orders".format(order_period, order_status,stakeholder),
            color='status_percentage',template='plotly_white') #tenplates = plotly_white plotly_dark ggplot2 simple_white seaborn presentation 
            fig.update_layout( height=800,margin=dict(t=120,l=0,b=20,r=0),
                 legend=dict(
                        title=None,)
            )
            fig.update_traces(textinfo="label+percent root")
            return fig

        else:
            fig = px.sunburst(sme_graph, path=[features_order_period[order_period],'order_status', features_stakeholder[stakeholder]], 
             values='status_percentage',   title="{} {} Status Percentage out of {} total orders".format(order_period, order_status,stakeholder),
            color='status_percentage',template='plotly_white') #tenplates = plotly_white plotly_dark ggplot2 simple_white seaborn presentation 
            fig.update_layout( height=800,margin=dict(t=120,l=0,b=20,r=0),
                 legend=dict(
                        title=None,)
            )
            fig.update_traces(textinfo="label+percent root")
            return fig

    def plots_percentage_traces(sme_graph,stakeholder,order_period):
        plot = 'px'
        if stakeholder!='Halan':
          
          
       

                
            r=len(sme_graph[features_stakeholder[stakeholder]].unique())           
            fig = make_subplots(rows=r+1, cols=1, specs=[[{'type':'scatter'}] for i in range(r+1)])
    
            stakeholder_list = sme_graph[features_stakeholder[stakeholder]].unique()
            traces = []

            for names in sme_graph[features_stakeholder[stakeholder]].unique():
                graph_df = sme_graph[sme_graph[features_stakeholder[stakeholder]]==names]
            
            
                traces.append(go.Scatter(
                x=graph_df[features_order_period[order_period]],
                        y=graph_df['status_percentage'],
                    textfont_size=14,
                        textposition='top right',
                    text = graph_df['status_percentage'],
                    texttemplate='%{text:.2%}',
                    mode = 'lines+markers+text',
                    
                    #hovertext = '{} {}'.format(names),
                    
                    name = names,
                    
                    marker = {'size':15, 'opacity':0.5,
                                    'line':{'width':0.5} },
                
                ))
            fig.add_traces(traces,1,1)
            it = 0
            for i in range(r):
                for j in range(1):
                    if r==0:
                        break
                    else:
                    
                        i=i+1
                       

                        df3 = sme_graph[sme_graph[features_stakeholder[stakeholder]]==(stakeholder_list[it])]
                        fig.add_trace( go.Scatter( x=df3[features_order_period[order_period]], y=df3['status_percentage'],text = df3['status_percentage'],
                            name = stakeholder_list[it], showlegend=False, 
                        mode = 'lines+markers+text'),
                            
                                i+1, j+1)
                        it= it+1


            fig.update_traces(textposition='top left',texttemplate='%{text:.2%}')
            if r>10:
                fig.update_layout( uniformtext_minsize=12, uniformtext_mode='hide',height=300*r+240,margin=dict(t=120,l=50,b=40,r=0),
                title='{} Order Status Percentage for {} '.format(order_period,stakeholder),
                legend=dict(
                title=None, orientation="h", y=0.9999, yanchor="bottom", x=0.7, xanchor="right",
                    ))
            else:
                fig.update_layout( uniformtext_minsize=12, uniformtext_mode='hide',height=300*r+240,margin=dict(t=120,l=50,b=40,r=50),
                title='{} Order Status Percentage for {} '.format(order_period,stakeholder),
                legend=dict(
                title=None, orientation="h", y=1, yanchor="bottom", x=1, xanchor="right",
                    ))
            

            return fig
        # if stakeholder=='Driver':
        #     n=2
        # else:
        #     n = len(sme_graph[features_stakeholder[stakeholder]].unique())//8
        # if plot =='px':
        #     fig = px.line(sme_graph, x=features_order_period[order_period], y='status_percentage',text = 'status_percentage',# log_y=True,
        #      title='{} {}'.format(stakeholder,order_period),color=features_stakeholder[stakeholder], 
        #      template = 'plotly_white')

        #     fig.update_layout(showlegend=True,   margin=dict(t=120,l=50,b=120,r=50),height=200*(n)+140,title='{} Order Status Percentage for {} '.format(order_period,stakeholder),
                                 
                                
        #                             legend=dict(
        #                 title=None, orientation="h", y=1, yanchor="bottom", x=1, xanchor="right"
        #             )
        #                         )
        #     fig.update_traces(texttemplate='%{text:.2%}',)

        #     return fig
        else:
            traces = []

            for names in sme_graph[features_stakeholder[stakeholder]].unique():
                graph_df = sme_graph[sme_graph[features_stakeholder[stakeholder]]==names]
            
            
                traces.append(go.Scatter(
                x=graph_df[features_order_period[order_period]],
                        y=graph_df['status_percentage'],
                    textfont_size=14,
                        textposition='top right',
                    text = graph_df['status_percentage'],
                    texttemplate='%{text:.2%}',
                    mode = 'lines+markers+text',
                    
                    #hovertext = '{} {}'.format(names),
                    
                    name = names,
                    
                    marker = {'size':15, 'opacity':0.5,
                                    'line':{'width':0.5} },
                
                ))

            return {'data': traces,
                    'layout':go.Layout(
                        title =  '{} order status percentage {} Plot:  '.format(stakeholder,order_period),
                        yaxis = dict(title = 'Order Status Percentage',tickformat= ',.2%',
                                    range= [0,1]),
                        xaxis= dict(title = '{}'.format(order_period)),
                        hovermode= 'closest',
                        
                    plot_bgcolor = css_styles['gray1']  ,
                        paper_bgcolor =css_styles['gray2'],
                        font= font1,
                        autosize = True,
                        showlegend=True,
                        margin=dict(l=100, r=0, t=40, b=50),
                )}
   
    # def plots_subplots_bar(sme_graph,stakeholder,order_period):
    #     plot = 'px'
    #     if stakeholder!='Halan':
    #             r_o_f =sme_graph['order_reason_of_failure'].unique()
    #             stakeholder_list = sme_graph[features_stakeholder[stakeholder]].unique()
    #             r=len(stakeholder_list)           
    #             fig = make_subplots(rows=r, cols=1, specs=[[{'type':'bar'}] for i in range(r)])
        
               
                
              
    #             it = 0
    #             for i in range(r):
    #                 for j in range(1):
    #                     if r==0:
    #                         break
    #                     else:
                      
          
    #                         df3 = sme_graph[sme_graph[features_stakeholder[stakeholder]]==(stakeholder_list[it])]
    #                         #df3 = sme_graph[sme_graph['order_reason_of_failure']==(r_o_f[it])]
    #                         fig.add_trace( go.Scatter( x=df3[features_order_period[order_period]], y=df3['order_count'],text = df3['order_reason_of_failure'],
    #                         name = stakeholder_list[it],
    #                         mode = 'markers+text',
    #                         marker_size =df3['order_count']*10,
    #                         marker = dict(color=[i for i in range(len(stakeholder_list))]),
    #                         ),     
    #                                 i+1, j+1)
    #                         it= it+1

                


    #             fig.update_traces(textposition='middle center')
    #             fig.update_layout( uniformtext_minsize=12, uniformtext_mode='hide',height=300*r+240,margin=dict(t=120,l=50,b=120,r=50),
                 
    #             legend=dict(
    #             title=None, orientation="h", y=1, yanchor="bottom", x=1, xanchor="right",
    #                 ))
                

    #             return fig
    #     if stakeholder=='Driver':
    #         n=2
    #     else:
    #         n = len(sme_graph[features_stakeholder[stakeholder]].unique())//8
    #     if plot =='px':
    #         fig = px.line(sme_graph, x=features_order_period[order_period], y='status_percentage',text = 'status_percentage',# log_y=True,
    #          title='{} {}'.format(stakeholder,order_period),color=features_stakeholder[stakeholder], 
    #          template = 'plotly_white')

    #         fig.update_layout(showlegend=True,   margin=dict(t=120,l=50,b=120,r=50),height=200*(n)+140, title='{} orders status percentage'.format(order_period),
                                 
                                
    #                                 legend=dict(
    #                     title=None, orientation="h", y=1, yanchor="bottom", x=1, xanchor="right"
    #                 )
    #                             )
    #         fig.update_traces(texttemplate='%{text:.2%}',)

    #         return fig            
        

    def plots_traces(sme_graph,stakeholder,order_period):
        plot = 'px'
        n = len(sme_graph[features_stakeholder[stakeholder]].unique())//5
        if plot =='px':
            fig = px.line(sme_graph, x=features_order_period[order_period], y='order_count',text = 'order_count',# log_y=True,
            color=features_stakeholder[stakeholder], 
             template = 'plotly_white')
           
            fig.update_layout(showlegend=True,   margin=dict(t=120,l=50,b=80,r=0),height=500+200,
                                 
                                 title='{} Order Count for {}'.format(order_period,stakeholder),
                                    legend=dict(
                        title=None, orientation="h", y=0.96, yanchor="bottom", x=0.9, xanchor="right"
                    )
                                )

            return fig
        else:    
            traces = []
            if stakeholder=='Halan':
                stakeholder = 'order_reason_of_failure'
                for names in sme_graph[stakeholder].unique():
                    graph_df = sme_graph[sme_graph[stakeholder]==names]
                    traces.append(go.Scatter(
                    y=graph_df['order_count'], 
                    x=graph_df[features_order_period[order_period]],
                    textfont_size=14,
                        textposition='bottom center',
                    text = graph_df['order_count'],
                    #texttemplate='%{text:.2%}',
                    mode = 'markers+text',
                    marker = {'size':15, 'opacity':0.5,
                                    'line':{'width':0.5} },
                    #hovertext = '{} {}'.format(names),
                
                    name = names,
                ))
            elif stakeholder=='Driver':
                fig = px.bar(sme_graph, x=features_order_period[order_period], y='order_count', facet_col="driver_name")
                
                fig.update_xaxes(type='category')
                return fig
            else:
                for names in sme_graph[features_stakeholder[stakeholder]].unique():
                    graph_df = sme_graph[sme_graph[features_stakeholder[stakeholder]]==names]
                    traces.append(go.Scatter(
                    y=graph_df['order_count'], 
                    x=graph_df[features_order_period[order_period]],
                    textfont_size=14,
                        textposition='bottom center',
                    text = graph_df['order_count'],
                    #texttemplate='%{text:.2%}',
                    mode = 'markers+text+lines',
                    marker = {'size':15, 'opacity':0.5,
                                    'line':{'width':0.5} },
                    #hovertext = '{} {}'.format(names),
                
                    name = names,
                ))
        
                

                return {'data': traces,
                        'layout':go.Layout(
                            title =  '{} Plot:  '.format(stakeholder),
                        # yaxis = dict(tickformat= ',.2%',
                            #            range= [0,1]),
                            yaxis = dict(title = 'Order Count'),
                            xaxis= dict(title = '{}'.format(order_period)),
                            hovermode= 'closest',
                            
                        plot_bgcolor = css_styles['gray1']  ,
                            paper_bgcolor =css_styles['gray2'],
                            font= font1,
                            autosize = True,
                    )}





    def plots(sme_graph,order_period,order_status):
        plot = 'px'
        if plot =='px':
            fig = px.line(sme_graph, x=features_order_period[order_period], y='order_count',text = 'order_count', 
            title='{} Order {} for Halan'.format(order_period,order_status),template = 'plotly_white')#tenplates = plotly_white plotly_dark ggplot2 simple_white seaborn
            fig.update_layout(showlegend=True,   margin=dict(t=120,l=10,b=20,r=10),height=500)
            

            return fig
        else:
            return {'data':[
                    
                    go.Scatter( x=sme_graph[features_order_period[order_period]],
                        y=sme_graph['order_count'],
                        
                        text=sme_graph['order_count'],
                        textfont_size=14,
                    textposition='top right',
                        mode='markers+text',
                        marker = dict(
                            size = 12,
                            color= css_styles['cyan'],
                            symbol = 'circle',
                            
                        line = {'width': 2}
                        )
                        ,
                    )],

                'layout':go.Layout(
                    title =  '{} orders received'.format(order_period),
                    xaxis = dict(title = order_period),
                    yaxis = dict(title = 'Order Count'),
                    autosize = True,
                                    
                    margin=dict(l=40, r=0, t=40, b=30),
                    
                plot_bgcolor = css_styles['gray1']  ,
                    paper_bgcolor =css_styles['gray2'],
                    
                    font= font1,
            ) }
        
                