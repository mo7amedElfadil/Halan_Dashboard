
from dash import dash_table
from datetime import date
import dash_bootstrap_components as dbc
from dash import html
from dash import dcc
import dash_daq as daq
from dash_application.input_data import input_data

from dash_application.static_dicts import tab_style, theme, NAVBAR_STYLE, art_style,features_graph_type,features_order_status,features_order_period,features_stakeholder,group_style,comp_style
sme_main = input_data()


confirm = dcc.ConfirmDialog(
id='confirm',
message='Danger danger! Are you sure you want to continue?'
)

confirbutton = dcc.ConfirmDialogProvider(
children=html.Button(
'Click Me',
),
id='danger-danger',
message='Danger danger! Are you sure you want to continue?'
),

store = dcc.Store(id='my-store', data={'my-data': 'data'}),



graduatedbar = daq.GraduatedBar(
id='my-daq-graduatedbar',
value=4
)


switch = daq.BooleanSwitch(
id='my-daq-booleanswitch',
on=True
)

colorpicker =daq.ColorPicker(
id='my-daq-colorpicker',
label="colorPicker"
)

indicator =daq.Indicator(
id='my-daq-indicator',
value=True,
color="#00cc96"
)

knob =daq.Knob(
    id='my-daq-knob',
min=0,
max=10,
value=8
)

leddisplay = daq.LEDDisplay(
id='my-daq-leddisplay',
value="3.14159"
)

numericinput = daq.NumericInput(
id='my-daq-numericinput',
min=0,
max=10,
value=5
)

slider =daq.Slider(
id='my-daq-slider',
value=17,
min=0,
max=100,
targets={"25": {"label": "TARGET"}}
)

tank = daq.Tank(
id='my-daq-tank',
min=0,
max=10,
value=5
)

toggle_switch = daq.ToggleSwitch(
id='daq-light-dark-theme',
label=['Light', 'Dark'],
style={'postition':'relative'},
value=False,
)

dark_theme_provider = daq.DarkThemeProvider(theme=theme)



#####################################
# Create Auxiliary Components Here
#####################################

def nav_bar():
    
    return html.Div(
    [
         dbc.Nav(
            [ 
         dbc.Row([
             dbc.Col( 
                        html.Img(src='assets/favicon.ico', height="50rem",width="50rem")
              ,width={'size':2} ,class_name="navbar-nav mr-auto"),
            
             dbc.Col([ dbc.Row(
                       dbc.NavbarBrand("Dashboard", className="navbar-brand",style={'font-size':'2rem'})
             )
                 ], width={'size':3,},class_name="navbar-nav mr-auto"),
             
            
        dbc.Col([
            dbc.Row([
                dbc.NavbarToggler(id="navbar-toggler", n_clicks=0),
            dbc.Collapse([
                    html.Br(),
                    dbc.Col([
                        
                             dbc.NavItem(dbc.NavLink("Home", href="/home",active="exact", external_link=True,class_name="nav-link",style={'font-size':'20px'}),class_name="nav-item"),
                  
                ],class_name="navbar-nav mr-auto"),

                    dbc.Col([
                        
                            dbc.NavItem(dbc.NavLink("DashBoard", href="/dashboard",active="exact", external_link=True,class_name="nav-link",style={'font-size':'20px'}),class_name="nav-item"),    
                     
                ],class_name="navbar-nav mr-auto"),
                    dbc.Col([
                         
                        dbc.NavItem(dbc.NavLink("DataTable", href="/datatable", active="exact", external_link=True,class_name="nav-link",style={'font-size':'20px'}),class_name="nav-item"),
                        

                ],class_name="navbar-nav mr-auto"),
                    dbc.Col([
                         
                        dbc.NavItem(dbc.NavLink("Report", href="/report", active="exact", external_link=True,class_name="nav-link",style={'font-size':'20px'}),class_name="nav-item"),
                        

                ],class_name="navbar-nav mr-auto"),
            
             ],
                
                id="navbar-collapse",
                is_open=False,
                navbar=True,
                
            ),
             ] ),
                #dbc.NavItem([toggle_switch,dcc.Location(id='url', refresh=False,)]),
          
           

                 ], width={'size':4,'offset':3,"order": "last"}, align ='center'),
        
          ],class_name='container-fluid',justify='evenly'),
          ],
            card = True,
            pills=True,
            
            horizontal=True,
            fill= True,
             class_name="navbar navbar-expand-lg navbar-dark bg-primary",
                   
        ),  
       
      
       
       
    ],
    
    )  
    


def drop_down_dashboard():
    return html.Div([ dbc.Row([
                dbc.Col([
                
            
                  
                                dcc.Dropdown(
                                    id = 'graph_type',
                                    options = [{'label':i, 'value': i } for i in features_graph_type],
                                    value = 'order_status_count',
                                    style=comp_style,

                                ) ,
                               
                     ] ,width={'size':3,'offset':0},xs =12,sm =6,md=3,lg =3, xl=3,xxl=3),
         
                dbc.Col([
                    
                    
                                dcc.Dropdown(
                                    id = 'order_status',
                                    options = [{'label':i, 'value': i } for i in features_order_status],
                                    value = 'Received',
                                        style=comp_style,

                                ), 
                                
                     ], width={'size':3,'offset':0},xs =12,sm =6,md=3,lg =3, xl=3,xxl=3),
                dbc.Col([
        
                                dcc.Dropdown(
                                    id = 'order_period',
                                    options = [{'label':i, 'value': i } for i in features_order_period],
                                    value = 'Daily',
                                     style=comp_style,


                                ) , 
                               

                      ], width={'size':3,'offset':0},xs =12,sm =6,md=3,lg =3, xl=3,xxl=3),  
                dbc.Col([    
                                dcc.Dropdown(
                                    id = 'stakeholder',
                                    options = [{'label':i, 'value': i } for i in features_stakeholder],
                                    value = 'Halan',
                                     style=comp_style,
                                ) , 
                                 
                    ], width={'size':3,'offset':0},xs =12,sm =6,md=3,lg =3, xl=3,xxl=3),              
           
            ], justify='evenly'),
        ])
    

    
def drop_down_dashboard_dynamic(n_clicks):
    return html.Div(id= {
                        'type':"drop_down",
                        'index' : n_clicks,                                        
                    }, children=[ dbc.Row([
                dbc.Col([
                
            
                  
                            graph_type_dropdown(n_clicks),
                               
                     ] ,width={'size':3,'offset':0},xs =12,sm =6,md=3,lg =3, xl=3,xxl=3),
         
                dbc.Col([
                    
                    
                            order_status_dropdown(n_clicks), 
                                
                     ], width={'size':3,'offset':0},xs =12,sm =6,md=3,lg =3, xl=3,xxl=3),
                dbc.Col([
        
                            order_period_dropdown(n_clicks), 
                               

                      ], width={'size':3,'offset':0},xs =12,sm =6,md=3,lg =3, xl=3,xxl=3),  
                dbc.Col([    
                            stakeholder_dropdown(n_clicks), 
                                 
                    ], width={'size':3,'offset':0},xs =12,sm =6,md=3,lg =3, xl=3,xxl=3),              
           
            ], justify='evenly'),
        ])
 
def drop_down_dashboard_dynamic2(n_clicks,n=30):
    return html.Div(
        children=[ dbc.Row([
               
                dbc.Col([    
                                knob_component(n_clicks,n), 
                                 
                    ], width={'size':3,'offset':0},xs =12,sm =6,md=3,lg =3, xl=3,xxl=3), 
                dbc.Col([    
                                date_picker_range_component(n_clicks), 
                                 
                    ], width={'size':3,'offset':0},xs =12,sm =6,md=3,lg =3, xl=3,xxl=3),    
                              
           
            ], justify='evenly'),
        ])
 

def tabs_component():
    return html.Div([
                     dcc.Tabs(id="tabs", value='dashboard', persistence=True,persistence_type='session' ,children=[
                     dcc.Tab(label='Dashboard', value='dashboard'),
                     dcc.Tab(label='Report', value='report'),
                     dcc.Tab(label='Data Table', value='data_table'),
                     ]),
                     html.Div(id='tabs-content', children=[]),
                    ],)



def multi_dropdown_component(column_name,n_clicks):
    choices = [{'label': x,'value': x} for x in sme_main[column_name].unique()]
    return dcc.Dropdown(
        id = {
            'type':column_name,
            'index' : n_clicks,                                        
        } ,
        options=choices,
        multi=True,
        clearable=False,
        value = {val for dic in choices for val in dic.values()}
        )

def gauge_component(stakeholder,n_clicks,x):
    return daq.Gauge(
        id = {
            'type':stakeholder,
            'index' : n_clicks,                                        
        } ,
        label=stakeholder,
        value=x
    )

def graduated_bar_component(stakeholder,n_clicks,x):
    return daq.GraduatedBar(
        id = {
            'type':stakeholder,
            'index' : n_clicks,                                        
        } ,
        label=stakeholder,
        value=x
    )

def date_picker_range_component(n_clicks):
     
    return dcc.DatePickerRange(
        id = {
            'type':'date-picker-range',
            'index' : n_clicks,                                        
        } ,
        min_date_allowed=date(2017, 1, 1),
        initial_visible_month=date(2021, 6, 1),
        start_date=date(2021, 6, 1),
        start_date_placeholder_text='Select a start date!',
        end_date=date.today(),
        end_date_placeholder_text='Select an end date!',
    )

def knob_component(n_clicks,n):
    return daq.Knob(
    id = {
            'type':'knob_component',
            'index' : n_clicks,                                        
        },
    min=0,
    max=n,
    value=5
    )


def graph_type_dropdown(n_clicks,graph_type='order_status_count'):
    return   dcc.Dropdown(
                                    id ={
                                        'type':'graph_type',
                                        'index' : n_clicks,                                        
                                    } ,
                                    options = [{'label':i, 'value': i } for i in features_graph_type],
                                    value = graph_type,
                                 

                                )

def order_status_dropdown(n_clicks):
    return  dcc.Dropdown(
                                    id ={
                                        'type':'order_status',
                                        'index' : n_clicks,                                        
                                    } , 
                                    options = [{'label':i, 'value': i } for i in features_order_status],
                                    value = 'Received',
                                 

                                )
def order_status_dropdown2(n_clicks,graph_type):
    if graph_type=="order_status_count" or graph_type=="order_status_percentage":    
        return   dbc.Col([ dcc.Dropdown(
                                        id ={
                                            'type':'order_status',
                                            'index' : n_clicks,                                        
                                        } , 
                                        options = [{'label':i, 'value': i } for i in features_order_status],
                                        value = 'Received',
                                    

                                    )    
                ], width={'size':3,'offset':0},xs =12,sm =6,md=3,lg =3, xl=3,xxl=3),
    else:
        return                           

def order_period_dropdown(n_clicks):
    return dcc.Dropdown(
                                    id = {
                                        'type':'order_period',
                                        'index' : n_clicks,                                        
                                    } ,
                                    options = [{'label':i, 'value': i } for i in features_order_period],
                                    value = 'Daily',
                                 


                                )
                             
def stakeholder_dropdown(n_clicks):
    return dcc.Dropdown(
                                    id ={
                                        'type':'stakeholder',
                                        'index' : n_clicks,                                        
                                    } , 
                                    options = [{'label':i, 'value': i } for i in features_stakeholder],
                                    value = 'Halan',
                                 
                                )