
from werkzeug.middleware.dispatcher import DispatcherMiddleware

from dash_application.dash_template import create_dash_app_datatable,create_dash_app, create_dash_app_dynamic,create_dash_app_report, create_dash_app_tabbed 

from Halanweb import app
from dash_application.input_data import input_data

sme_main = input_data()




dash_app1 = create_dash_app_tabbed(app,'/dashboard/')

# dash_app2 = create_dash_app_report(app,'/report/')
# dash_app3 = create_dash_app_datatable(app, '/datatable/')



app1 = DispatcherMiddleware(app, {
    '/dashboard': dash_app1.server,
    # '/report': dash_app2.server,
    # '/datatable': dash_app3.server,
})


import dash_application.callbacks 