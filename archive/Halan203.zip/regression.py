import numpy as np
import pandas as pd
# import matplotlib.pyplot as plt 
# import seaborn as sns
from sklearn.model_selection import train_test_split
from dash_application.input_data import input_data
import statsmodels.api as sm
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score

sme_main = input_data()

sme_gmv =  sme_main.groupby('order_date')[['driver_fee', 'halan_return','sme_return','order_value']].sum().reset_index()


daily_order_status =pd.DataFrame(sme_main.groupby('order_date')['order_status'].value_counts()).rename(columns={'order_status': 'order_count'}).reset_index()
options = ['Delivered','Cancelled','Hold']
option = 'Delivered'
orders_delivered_daily = daily_order_status[ (daily_order_status['order_status']=='Delivered')].drop('order_status', axis=1)
orders_cancelled_daily = daily_order_status[ (daily_order_status['order_status']=='Cancelled')].drop('order_status', axis=1)
orders_hold_daily = daily_order_status[ (daily_order_status['order_status']=='Hold')].drop('order_status', axis=1)
orders_received_daily =pd.DataFrame(sme_main.groupby('order_date')['order_date'].value_counts()).reset_index(level=1, drop=True).rename(columns={'order_date': 'order_count'}).reset_index()


halan_regression = pd.merge(sme_gmv,orders_delivered_daily,how='inner',on='order_date').rename(columns={'order_count': 'Delivered'})
halan_regression = pd.merge(halan_regression,orders_received_daily,how='inner',on='order_date').rename(columns={'order_count': 'Received'})
halan_regression['delivered_percentage']=(halan_regression['Delivered']/halan_regression['Received'])

# halan_regression.describe()
# halan_regression.corr()

# fig, axs = plt.subplots(4, figsize = (5,5))
# plt1 = sns.boxplot(halan_regression['Delivered'], ax = axs[0])
# plt2 = sns.boxplot(halan_regression['Received'], ax = axs[1])
# plt3 = sns.boxplot(halan_regression['halan_return'], ax = axs[2])
# plt1 = sns.boxplot(halan_regression['delivered_percentage'], ax = axs[3])
# plt.tight_layout()

# sns.pairplot(halan_regression, x_vars=['Delivered', 'Received', 'order_value','delivered_percentage'], y_vars='halan_return', height=4, aspect=1, kind='scatter')
# plt.show()

# sns.heatmap(halan_regression.corr(), cmap="YlGnBu", annot = True)
# plt.show()

y = halan_regression['delivered_percentage'] #Delivered
X = halan_regression['halan_return']
#days of the week with orders per day

X_train, X_test, y_train, y_test = train_test_split(X, y, train_size = 0.7, test_size = 0.3, random_state = 100)


# Add a constant to get an intercept
X_train_sm = sm.add_constant(X_train)

# Fit the resgression line using 'OLS'
lr = sm.OLS(y_train, X_train_sm).fit()

# lr.params
# print(lr.summary())

# plt.scatter(X_train, y_train)
# plt.plot(X_train,  7.097811e-01 +  -6.975634e-07*X_train, 'r')
# plt.show()

y_train_pred = lr.predict(X_train_sm)
res = (y_train - y_train_pred)


# fig = plt.figure()
# sns.distplot(res, bins = 15)
# fig.suptitle('Error Terms', fontsize = 15)                  # Plot heading 
# plt.xlabel('y_train - y_train_pred', fontsize = 15)         # X-label
# plt.show()

# plt.scatter(X_train,res)
# plt.show()

# Add a constant to X_test
X_test_sm = sm.add_constant(X_test)

# Predict the y values corresponding to X_test_sm
y_pred = lr.predict(X_test_sm)




np.sqrt(mean_squared_error(y_test, y_pred))


# plt.scatter(X_test, y_test)

r_squared = r2_score(y_test, y_pred)
r_squared

# plt.plot(X_test,  7.097811e-01 +  -6.975634e-07 * X_test, 'r')
# plt.show()






