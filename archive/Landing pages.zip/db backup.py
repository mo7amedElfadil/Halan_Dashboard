from Halanweb import db,bcrypt
from Halanweb.models import User

admin =User(username='admin',email='admin@blog.com',password=bcrypt.generate_password_hash('admin').decode('utf-8'),role='admin')
db.session.add(admin)
db.session.commit()