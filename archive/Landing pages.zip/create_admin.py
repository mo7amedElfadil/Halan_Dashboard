from Halanweb import db,bcrypt
from Halanweb.models import User
db.drop_all()
db.create_all()
 
admin =User(username='admin',email='admin@blog.com',password=bcrypt.generate_password_hash('admin').decode('utf-8'))
db.session.add(admin)
db.session.commit()
